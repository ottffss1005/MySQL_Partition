drop table if exists spotify_songs_partitioned;

CREATE TABLE spotify_songs_partitioned (
  id INT NOT NULL,
  track_id VARCHAR(22),
  artists VARCHAR(600),
  album_name VARCHAR(300),
  track_name VARCHAR(600),
  popularity INT,
  duration_ms INT,
  explicit TINYINT(1),
  danceability FLOAT,
  energy FLOAT,
  key_col INT,
  loudness FLOAT,
  mode_col INT,
  speechiness FLOAT,
  acousticness FLOAT,
  instrumentalness FLOAT,
  liveness FLOAT,
  valence FLOAT,
  tempo FLOAT,
  time_signature INT,
  track_genre VARCHAR(50) NOT NULL,
  PRIMARY KEY (id, track_genre)
)
ENGINE=InnoDB
PARTITION BY LIST COLUMNS(track_genre)
SUBPARTITION BY HASH(id)
SUBPARTITIONS 8 (
  PARTITION p_pop VALUES IN ('pop', 'pop-film', 'power-pop', 'indie-pop', 'synth-pop', 'swedish', 'romance', 'party'),
  PARTITION p_rock VALUES IN ('rock', 'alt-rock', 'punk', 'punk-rock', 'hard-rock', 'grunge', 'emo',
    'rock-n-roll', 'rockabilly', 'psych-rock', 'garage', 'guitar', 'alternative'),
  PARTITION p_electronic VALUES IN (
    'edm', 'electronic', 'electro', 'techno', 'trance', 'trip-hop', 'deep-house',
    'detroit-techno', 'minimal-techno', 'progressive-house', 'chicago-house', 'idm',
    'breakbeat', 'house', 'club', 'dubstep', 'dub', 'drum-and-bass', 'ambient', 'chill'
  ),
  PARTITION p_metal VALUES IN (
    'metal', 'black-metal', 'death-metal', 'metalcore', 'grindcore',
    'heavy-metal', 'hardcore', 'hardstyle', 'industrial'
  ),
  PARTITION p_hiphoprnb VALUES IN (
    'hip-hop', 'r-n-b'
  ),
  PARTITION p_jazzbluesclassical VALUES IN (
    'jazz', 'blues', 'classical', 'piano', 'opera'
  ),
  PARTITION p_latin VALUES IN (
    'latin', 'latino', 'samba', 'salsa', 'pagode', 'mpb', 'brazil', 'forro', 'sertanejo'
  ),
  PARTITION p_worldtraditional VALUES IN (
    'indian', 'mandopop', 'cantopop', 'malay', 'iranian', 'turkish', 'j-pop',
    'j-rock', 'j-idol', 'j-dance', 'anime', 'world-music', 'k-pop'
  ),
  PARTITION p_indiefolk VALUES IN (
    'indie', 'folk', 'singer-songwriter', 'songwriter', 'acoustic'
  ),
  PARTITION p_other VALUES IN (
    'afrobeat', 'bluegrass', 'british', 'children', 'comedy', 'country',
    'dance', 'dancehall', 'disco', 'disney', 'funk', 'french', 'german',
    'gospel', 'goth', 'groove', 'happy', 'honky-tonk', 'kids', 'new-age',
    'sad', 'show-tunes', 'ska', 'sleep', 'soul', 'spanish', 'study', 'tango',
    'reggae', 'reggaeton'
  )
);

-- 장르 다 출력
SELECT DISTINCT LOWER(TRIM(track_genre)) AS genre
FROM spotify
WHERE track_genre IS NOT NULL AND TRIM(track_genre) != ''
ORDER BY genre;


-- 데이터 insert하기
INSERT INTO spotify_songs_partitioned (
  id, track_id, artists, album_name, track_name, popularity,
  duration_ms, explicit, danceability, energy, key_col, loudness,
  mode_col, speechiness, acousticness, instrumentalness, liveness,
  valence, tempo, time_signature, track_genre
)
SELECT
  id, track_id, artists, album_name, track_name, popularity,
  duration_ms, explicit, danceability, energy, key_col, loudness,
  mode_col, speechiness, acousticness, instrumentalness, liveness,
  valence, tempo, time_signature,
  LOWER(TRIM(track_genre)) AS track_genre
FROM spotify
WHERE track_genre IS NOT NULL
  AND TRIM(track_genre) != ''
  AND LOWER(TRIM(track_genre)) IN (
    'pop', 'pop-film', 'power-pop', 'indie-pop', 'synth-pop', 'swedish', 'romance', 'party',
    'rock', 'alt-rock', 'punk', 'punk-rock', 'hard-rock', 'grunge', 'emo',
    'rock-n-roll', 'rockabilly', 'psych-rock', 'garage', 'guitar', 'alternative',
    'edm', 'electronic', 'electro', 'techno', 'trance', 'trip-hop', 'deep-house',
    'detroit-techno', 'minimal-techno', 'progressive-house', 'chicago-house', 'idm',
    'breakbeat', 'house', 'club', 'dubstep', 'dub', 'drum-and-bass', 'ambient', 'chill',
    'metal', 'black-metal', 'death-metal', 'metalcore', 'grindcore',
    'heavy-metal', 'hardcore', 'hardstyle', 'industrial',
    'hip-hop', 'r-n-b',
    'jazz', 'blues', 'classical', 'piano', 'opera',
    'latin', 'latino', 'samba', 'salsa', 'pagode', 'mpb', 'brazil', 'forro', 'sertanejo',
    'indian', 'mandopop', 'cantopop', 'malay', 'iranian', 'turkish', 'j-pop',
    'j-rock', 'j-idol', 'j-dance', 'anime', 'world-music', 'k-pop',
    'indie', 'folk', 'singer-songwriter', 'songwriter', 'acoustic',
    'afrobeat', 'bluegrass', 'british', 'children', 'comedy', 'country',
    'dance', 'dancehall', 'disco', 'disney', 'funk', 'french', 'german',
    'gospel', 'goth', 'groove', 'happy', 'honky-tonk', 'kids', 'new-age',
    'sad', 'show-tunes', 'ska', 'sleep', 'soul', 'spanish', 'study', 'tango',
    'reggae', 'reggaeton'
  );


SELECT
  PARTITION_NAME, SUBPARTITION_NAME, TABLE_ROWS
FROM
  INFORMATION_SCHEMA.PARTITIONS
WHERE
  TABLE_NAME = 'spotify_songs_partitioned';

EXPLAIN SELECT * 
FROM spotify_songs_partitioned
WHERE track_genre = 'pop'

-- 인덱싱 해보기
CREATE INDEX idx_track_genre_pop ON spotify_songs_partitioned(track_genre, popularity);
CREATE INDEX idx_popularity ON spotify_songs_partitioned(popularity);

SELECT * 
FROM spotify_songs_partitioned
WHERE track_genre = 'hip-hop'
ORDER BY popularity DESC
LIMIT 10;
