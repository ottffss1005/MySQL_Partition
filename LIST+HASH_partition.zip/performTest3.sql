-- 1. 프로파일링 기능 켜기
SET profiling = 1;

-- 2. 첫 번째 쿼리 실행

SELECT * FROM spotify
WHERE track_genre = 'pop'
  AND popularity > 70
ORDER BY popularity DESC
LIMIT 50;


-- 3. 두 번째 쿼리 실행

SELECT * FROM spotify_songs_partitioned
WHERE track_genre = 'pop'
  AND popularity > 70
ORDER BY popularity DESC
LIMIT 50;

-- 4. 실행된 쿼리 목록 보기
SHOW PROFILES;

-- 5. 각 쿼리의 CPU 시간 상세 보기
SHOW PROFILE CPU FOR QUERY 17;
SHOW PROFILE CPU FOR QUERY 18;