-- 원본 테이블 성능 측정
SET @start1 = CURRENT_TIMESTAMP(3);
SELECT * FROM spotify
WHERE LOWER(TRIM(track_genre)) = 'pop'
  AND popularity > 70
ORDER BY popularity DESC
LIMIT 50;
SET @end1 = CURRENT_TIMESTAMP(3);

-- 파티셔닝 테이블 성능 측정
SET @start2 = CURRENT_TIMESTAMP(3);
SELECT * FROM spotify_songs_partitioned
WHERE track_genre = 'pop'
  AND popularity > 70
ORDER BY popularity DESC
LIMIT 50;
SET @end2 = CURRENT_TIMESTAMP(3);

-- 실행 시간 비교 (ms 단위)
SELECT 
  TIMESTAMPDIFF(MICROSECOND, @start1, @end1)/1000 AS 원본_실행시간_ms,
  TIMESTAMPDIFF(MICROSECOND, @start2, @end2)/1000 AS 파티셔닝_실행시간_ms;


EXPLAIN
SELECT * FROM spotify_songs_partitioned
WHERE track_genre = 'pop'
  AND popularity > 70
ORDER BY popularity DESC
LIMIT 50;

