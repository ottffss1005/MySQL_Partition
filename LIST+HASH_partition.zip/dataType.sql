-- 1. 전체 장르 종류와 개수
SELECT track_genre, COUNT(*) AS 곡수
FROM spotify
GROUP BY track_genre
ORDER BY 곡수 DESC;

-- 2. popularity 점수별 곡 개수 (0~100)
SELECT popularity, COUNT(*) AS 곡수
FROM spotify
GROUP BY popularity
ORDER BY popularity DESC;

-- 3. explicit(욕설 포함 여부: True/False) 분포
SELECT explicit, COUNT(*) AS 곡수
FROM spotify
GROUP BY explicit;

-- 4. 음악 key 값 분포 (C~B: 0~11)
SELECT 'key', COUNT(*) AS 곡수
FROM spotify
GROUP BY 'key'
ORDER BY 'key';

-- 5. 음악 mode 분포 (0 = minor, 1 = major)
SELECT `mode`, COUNT(*) AS 곡수
FROM spotify
GROUP BY `mode`;

-- 6. time_signature (박자) 분포
SELECT time_signature, COUNT(*) AS 곡수
FROM spotify
GROUP BY time_signature
ORDER BY time_signature;

-- 7. duration_ms (재생 시간 밀리초) 분포 상위 20개
SELECT duration_ms, COUNT(*) AS 곡수
FROM spotify
GROUP BY duration_ms
ORDER BY 곡수 DESC
LIMIT 20;

-- 8. tempo (템포, 10단위로 구간화하여 분포 보기)
SELECT
    FLOOR(tempo / 10) * 10 AS tempo_range,
    COUNT(*) AS 곡수
FROM spotify
GROUP BY tempo_range
ORDER BY tempo_range;

-- 9. valence (명랑도) 값 분포 상위 20개
SELECT valence, COUNT(*) AS 곡수
FROM spotify
GROUP BY valence
ORDER BY 곡수 DESC
LIMIT 20;

-- 10. energy 값 분포 상위 20개
SELECT energy, COUNT(*) AS 곡수
FROM spotify
GROUP BY energy
ORDER BY 곡수 DESC
LIMIT 20;

-- 11. danceability (춤 추기 좋은 정도) 분포 상위 20개
SELECT danceability, COUNT(*) AS 곡수
FROM spotify
GROUP BY danceability
ORDER BY 곡수 DESC
LIMIT 20;

-- 12. acousticness (어쿠스틱 특성) 분포 상위 20개
SELECT acousticness, COUNT(*) AS 곡수
FROM spotify
GROUP BY acousticness
ORDER BY 곡수 DESC
LIMIT 20;

-- 13. instrumentalness (기악적 정도) 분포 상위 20개
SELECT instrumentalness, COUNT(*) AS 곡수
FROM spotify
GROUP BY instrumentalness
ORDER BY 곡수 DESC
LIMIT 20;

-- 14. speechiness (말의 비율) 분포 상위 20개
SELECT speechiness, COUNT(*) AS 곡수
FROM spotify
GROUP BY speechiness
ORDER BY 곡수 DESC
LIMIT 20;

-- 15. liveness (라이브 공연 느낌) 분포 상위 20개
SELECT liveness, COUNT(*) AS 곡수
FROM spotify
GROUP BY liveness
ORDER BY 곡수 DESC
LIMIT 20;
