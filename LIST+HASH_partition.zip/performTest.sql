-- 원본 테이블
SET @start_time3 = CURRENT_TIMESTAMP(3);
SELECT * FROM spotify
WHERE popularity BETWEEN 61 AND 80
ORDER BY popularity DESC;
-- LIMIT 100;
SET @end_time3 = CURRENT_TIMESTAMP(3);

-- 파티셔닝 테이블
SET @start_time4 = CURRENT_TIMESTAMP(3);
SELECT * FROM spotify_songs_partitioned
WHERE popularity BETWEEN 61 AND 80
ORDER BY popularity DESC;
-- LIMIT 100;
SET @end_time4 = CURRENT_TIMESTAMP(3);

-- 실행 시간 비교
SELECT 
  TIMESTAMPDIFF(MICROSECOND, @start_time3, @end_time3) / 1000 AS 원본_정렬_실행시간_ms,
  TIMESTAMPDIFF(MICROSECOND, @start_time4, @end_time4) / 1000 AS 파티셔닝_정렬_실행시간_ms;